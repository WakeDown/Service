SELECT * FROM dbo.srvpl_service_intervals si 

select c.id_contract
from dbo.srvpl_contracts c
WHERE c.enabled = 1 AND c.number = N''

/*
UPDATE dbo.srvpl_contract2devices
SET id_service_interval = 
WHERE id_contract = 
*/